# عالم ثاني 2027 🌏 | SECOND WORLD — Netlify Edition

هذه النسخة مخصصة للنشر على **Netlify كـ Static Site**.

## النشر
1. فك ضغط الملف.
2. ادخل إلى Netlify.
3. اختر **Add new site → Deploy manually**.
4. اسحب **مجلد المشروع كاملًا** أو ملف ZIP إلى منطقة الرفع حسب واجهة Netlify.
5. يجب أن يكون `index.html` في جذر الملفات المنشورة.

## نموذج التواصل
النموذج يستخدم Netlify Forms:
- `name="project-request"`
- يدعم الاسم، الهاتف، نوع المشروع، التفاصيل، وملفًا اختياريًا.
- بعد أول Deploy افتح Netlify → Forms لرؤية الطلبات.

> ملاحظة: رفع الملفات الكبيرة مثل MP4 عبر نموذج Netlify قد يخضع لحدود الخطة. الأفضل للفيديوهات الكبيرة استخدام Cloudinary / Bunny / S3 أو CMS.

## لوحة الإدارة
المسار `/admin/` موجود كواجهة تمهيدية. إدارة المحتوى الحقيقية لا يمكن حفظها داخل ملفات Static على Netlify وحدها. للوحة كاملة نوصي بربط:
- Decap CMS + Git Gateway
- أو Sanity
- أو Supabase
- أو Cloudinary للوسائط

الواجهة الحالية مصممة بحيث يمكن ربطها لاحقًا بدون إعادة بناء التصميم.

## إضافة أعمال
بيانات الأعمال التجريبية موجودة في `app.js` داخل المتغير `works`.
يمكن استبدالها ببيانات أعمال حقيقية، أو تحويلها لاحقًا إلى CMS/API.

## بيانات الاتصال
- WhatsApp: +967 773 546 637
- Email: king.of.happiness.design@gmail.com
- Pinterest reference: https://pin.it/6uFYoGdKw

## قبل الإطلاق
استبدل `YOUR-SITE.netlify.app` في:
- index.html
- sitemap.xml
- robots.txt

بالدومين الحقيقي للموقع.

## ملاحظات
الرابط المختصر في Pinterest أُدرج كمرجع مباشر، ولم يتم نسخ محتوى الصور من Pinterest. جميع العناصر البصرية الأساسية في الموقع مصنوعة داخل CSS/SVG لتقليل الاعتماد على ملفات خارجية.
