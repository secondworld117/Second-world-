const WA="967773546637";
const translations={
ar:{
"nav.home":"الرئيسية","nav.services":"الخدمات","nav.work":"الأعمال","nav.about":"من نحن","nav.contact":"تواصل معنا","nav.start":"ابدأ مشروعك",
"hero.line1":"نحوّل الأفكار","hero.line2":"إلى عالمٍ يُرى.","hero.desc":"عالم ثاني مساحة إبداعية لصناعة التصاميم والإعلانات والهويات البصرية والمحتوى الرقمي بأسلوب عصري، أنيق ومختلف.","hero.work":"✦ استكشف أعمالنا","hero.chat":"💬 تحدث معنا",
"stats.one":"رؤية جديدة","stats.two":"أفكار بلا حدود","stats.three":"حضور رقمي",
"services.title":"كل فكرة تستحق تصميمًا استثنائيًا.","services.sub":"خدمات إبداعية متكاملة من الفكرة إلى الظهور النهائي.",
"work.title":"معرض الإبداعات","work.sub":"مساحة جاهزة لعرض أعمالك الحقيقية وتحديثها باستمرار.",
"about.title":"نصنع حضورًا بصريًا لا يُنسى.","about.text":"عالم ثاني مساحة إبداعية تهتم بتحويل الأفكار إلى تجارب بصرية واضحة، جذابة واحترافية. نعمل في التصميم والإعلان والهوية البصرية والمحتوى الرقمي مع اهتمام بالتفاصيل التي تجعل العلامات أكثر حضورًا وتميزًا.",
"faq.title":"أسئلة سريعة","contact.title":"جاهز نصنع شيئًا مختلفًا؟","contact.sub":"أرسل فكرتك وسنحوّلها إلى حضور بصري يليق بها.",
"form.name":"الاسم","form.phone":"رقم الهاتف","form.type":"نوع المشروع","form.details":"تفاصيل المشروع","form.file":"ملف مرفق (اختياري)","form.send":"🚀 إرسال الطلب","form.note":"يمكنك أيضًا التواصل مباشرة عبر واتساب للرد الأسرع."
},
en:{
"nav.home":"Home","nav.services":"Services","nav.work":"Work","nav.about":"About","nav.contact":"Contact","nav.start":"Start a project",
"hero.line1":"We turn ideas","hero.line2":"into a world you can see.","hero.desc":"Second World is a creative studio for design, advertising, visual identity and digital content with a modern, elegant and distinctive approach.","hero.work":"✦ Explore our work","hero.chat":"💬 Talk to us",
"stats.one":"A new vision","stats.two":"Ideas without limits","stats.three":"Digital presence",
"services.title":"Every idea deserves exceptional design.","services.sub":"End-to-end creative services, from concept to final presence.",
"work.title":"Creative Showcase","work.sub":"A ready space for your real work, continuously updated.",
"about.title":"We build visual presence that lasts.","about.text":"Second World turns ideas into clear, attractive and professional visual experiences across design, advertising, visual identity and digital content, with attention to details that help brands stand out.",
"faq.title":"Quick FAQ","contact.title":"Ready to create something different?","contact.sub":"Send your idea and we’ll turn it into a visual presence worthy of it.",
"form.name":"Name","form.phone":"Phone","form.type":"Project type","form.details":"Project details","form.file":"Attachment (optional)","form.send":"🚀 Send request","form.note":"You can also contact us directly on WhatsApp for a faster response."
}};
const services={
ar:[
["◈","الهوية والشعارات","تصميم الشعارات والهوية البصرية ودليل الهوية والألوان والخطوط."],
["✦","الإعلانات والتسويق","منشورات إعلانية وعروض تجارية وإعلانات المنتجات والحملات الرقمية."],
["▣","السوشيال ميديا","Instagram وFacebook وTikTok وStories وCovers."],
["▶","الفيديو والموشن","مونتاج وMotion Graphics وإعلانات فيديو وReels."],
["◇","المطبوعات","بطاقات وبروشرات ولوحات وشهادات ودعوات ومنيوهات."],
["◎","المحتوى الرقمي","إنفوجرافيك وعروض تقديمية وملفات تعريفية ومحتوى بصري."]
],
en:[
["◈","Logos & Identity","Logo design, visual identity systems, brand guides, colors and typography."],
["✦","Advertising & Marketing","Ad posts, commercial decks, product ads and digital campaigns."],
["▣","Social Media","Instagram, Facebook, TikTok, Stories and Covers."],
["▶","Video & Motion","Editing, motion graphics, video ads and Reels."],
["◇","Print Design","Cards, brochures, signs, certificates, invitations and menus."],
["◎","Digital Content","Infographics, presentations, profiles and visual content."]
]};
const cats={ar:["الكل","الهوية","السوشيال","المطبوعات","الإعلانات","الفيديو"],en:["All","Identity","Social","Print","Advertising","Video"]};
const types={ar:["شعار","هوية بصرية","إعلان","منشور","فيديو","بطاقة","دعوة","أخرى"],en:["Logo","Visual identity","Ad","Social post","Video","Card","Invitation","Other"]};
const faqs={ar:[
["كم يستغرق تنفيذ المشروع؟","تختلف المدة حسب حجم ونوع المشروع ويتم تحديدها عند الاتفاق."],
["هل توجد تعديلات؟","نعم، يتم تنفيذ عدد التعديلات المتفق عليه ضمن نطاق المشروع."],
["هل توفرون تصميمات للطباعة؟","نعم، مع تجهيز الملفات بالمقاسات والصيغ المناسبة."],
["هل يمكن تنفيذ هوية بصرية كاملة؟","نعم، من الشعار والألوان والخطوط إلى دليل الهوية والتطبيقات."]
],en:[
["How long does a project take?","Timing depends on the project type and scope and is agreed before work starts."],
["Are revisions included?","Yes, according to the number of revisions agreed for the project."],
["Do you prepare print-ready files?","Yes, files can be prepared in suitable sizes and formats for print."],
["Can you build a complete identity?","Yes, from logo, colors and typography to brand guidelines and applications."]
]};
let lang=localStorage.getItem("sw_lang")||"ar";
let works=[
 {title:"Future Identity",category:"الهوية",desc:"هوية بصرية مستقبلية — نموذج عرض.",media:""},
 {title:"Digital Campaign",category:"الإعلانات",desc:"حملة رقمية — نموذج عرض.",media:""},
 {title:"Social Visual",category:"السوشيال",desc:"تصميم محتوى اجتماعي — نموذج عرض.",media:""}
];
function applyLang(){
 document.documentElement.lang=lang; document.documentElement.dir=lang==="ar"?"rtl":"ltr";
 document.querySelectorAll("[data-i18n]").forEach(el=>{let k=el.dataset.i18n;if(translations[lang][k])el.textContent=translations[lang][k]});
 renderServices();renderFilters();renderTypes();renderFaq();renderWorks("all");
}
function renderServices(){servicesGrid.innerHTML=services[lang].map(s=>`<article class="service reveal visible"><div class="icon">${s[0]}</div><h3>${s[1]}</h3><p>${s[2]}</p></article>`).join("")}
function renderFilters(){filters.innerHTML=cats[lang].map((c,i)=>`<button class="filter ${i===0?"active":""}" data-cat="${i===0?"all":c}">${c}</button>`).join("");filters.querySelectorAll(".filter").forEach(b=>b.onclick=()=>{filters.querySelectorAll(".filter").forEach(x=>x.classList.remove("active"));b.classList.add("active");renderWorks(b.dataset.cat)})}
function renderTypes(){projectType.innerHTML=types[lang].map(x=>`<option>${x}</option>`).join("")}
function renderFaq(){faqList.innerHTML=faqs[lang].map(x=>`<details><summary>${x[0]}</summary><p>${x[1]}</p></details>`).join("")}
function renderWorks(cat){
 let list=cat==="all"?works:works.filter(w=>w.category===cat);
 portfolio.innerHTML=list.length?list.map((w,i)=>`<article class="work" data-index="${works.indexOf(w)}"><div class="work-media">${w.media?(/\.(mp4|webm)$/i.test(w.media)?`<video src="${w.media}" muted autoplay loop playsinline></video>`:`<img src="${w.media}" alt="${w.title}" loading="lazy">`):"SECOND WORLD"}</div><div class="work-body"><small>${w.category}</small><h3>${w.title}</h3><p>${w.desc}</p></div></article>`).join(""):`<div class="empty">${lang==="ar"?"أضف أعمالك الحقيقية من خلال استبدال بيانات العرض داخل app.js أو ربط CMS لاحقًا.":"Add your real work by replacing the demo data in app.js or connecting a CMS later."}</div>`;
 document.querySelectorAll(".work").forEach(el=>el.onclick=()=>openWork(Number(el.dataset.index)));
}
function openWork(i){const w=works[i];lightboxTitle.textContent=w.title;lightboxDesc.textContent=w.desc;lightboxMedia.innerHTML=w.media?(/\.(mp4|webm)$/i.test(w.media)?`<video src="${w.media}" controls autoplay></video>`:`<img src="${w.media}" alt="${w.title}">`):`<div class="work-media" style="width:min(60vw,600px);aspect-ratio:4/3;border-radius:16px">SECOND WORLD</div>`;lightboxWa.href=`https://wa.me/${WA}?text=${encodeURIComponent((lang==="ar"?"السلام عليكم، أريد تصميمًا مشابهًا لمشروع ":"Hello, I’d like a design similar to ") + w.title)}`;lightbox.classList.add("open");lightbox.setAttribute("aria-hidden","false")}
closeLightbox.onclick=()=>{lightbox.classList.remove("open");lightboxMedia.innerHTML=""};lightbox.onclick=e=>{if(e.target===lightbox)closeLightbox.onclick()};
langBtn.onclick=()=>{lang=lang==="ar"?"en":"ar";localStorage.setItem("sw_lang",lang);applyLang()};
menuBtn.onclick=()=>mainNav.classList.toggle("open");
document.querySelectorAll("#mainNav a").forEach(a=>a.onclick=()=>mainNav.classList.remove("open"));
window.addEventListener("scroll",()=>nav.classList.toggle("scrolled",scrollY>20));
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting)e.target.classList.add("visible")}),{threshold:.12});document.querySelectorAll(".reveal").forEach(x=>io.observe(x));
document.querySelector(".project-form").addEventListener("submit",()=>{setTimeout(()=>alert(lang==="ar"?"تم إرسال الطلب. سنعود إليك قريبًا.":"Your request was sent. We’ll get back to you soon."),150)});
if("serviceWorker" in navigator)navigator.serviceWorker.register("/sw.js").catch(()=>{});
applyLang();